# lightstrafe
A first person shooter with platforming
