# Antergos Welcomed (DBus Service)
DBus service for [antergos-welcome](https://github.com/antergos/antergos-welcome)

## Dependencies
- python-dbus (pydbus)
- python-gobject

