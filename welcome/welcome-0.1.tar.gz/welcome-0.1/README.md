![screenshot](https://raw.github.com/jkw/antergos-welcome/master/screenshot.png)

antergos-welcome
================

Antergos welcome screen

* python3
* gtk
* python-simplejson
